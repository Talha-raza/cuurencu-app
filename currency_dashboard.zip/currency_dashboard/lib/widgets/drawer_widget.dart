import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DrawerWidget extends StatelessWidget {
  Future<String?> getUserName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('userName') ?? 'Guest'; // Fetch the user's name (if saved)
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          FutureBuilder<String?>(
            future: getUserName(),
            builder: (context, snapshot) {
              String userName = snapshot.data ?? 'Guest';
              return DrawerHeader(
                decoration: BoxDecoration(color: Colors.blue),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      userName,
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "Currency Dashboard",
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ],
                ),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.swap_horiz),
            title: Text("Currency Conversion"),
            onTap: () {
              Navigator.pushNamed(context, '/currency_conversion');
            },
          ),
          ListTile(
            leading: Icon(Icons.location_on),
            title: Text("Region Specific Tax"),
            onTap: () {
              Navigator.pushNamed(context, '/region_tax');  // Navigate to RegionSpecificTaxScreen
            },
          ),
          ListTile(
            leading: Icon(Icons.language),
            title: Text("Country with Currency"),
            onTap: () {
              Navigator.pushNamed(context, '/country_currency');  // Navigate to CountryCurrencyScreen
            },
          ),
          // ListTile(
          //   leading: Icon(Icons.account_balance_wallet),
          //   title: Text("Wallet"),
          //   onTap: () {
          //     Navigator.pushNamed(context, '/wallet');
          //   },
          // ),
          // ListTile(
          //   leading: Icon(Icons.receipt),
          //   title: Text("Receipts"),
          //   onTap: () {
          //     Navigator.pushNamed(context, '/receipt');
          //   },
          // ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text("Settings"),
            onTap: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),

          ListTile(
            leading: Icon(Icons.logout),
            title: Text("Logout"),
            onTap: () async {
              SharedPreferences prefs = await SharedPreferences.getInstance();
              await prefs.setBool('isLoggedIn', false);
              await prefs.remove('userName'); // Clear user info if necessary
              Navigator.pushReplacementNamed(context, '/login');
            },

          ),
        ],
      ),
    );
  }
}
