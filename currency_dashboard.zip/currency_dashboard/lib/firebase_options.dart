import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'dart:io' show Platform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (Platform.isAndroid) {
      return android;
    } else if (Platform.isIOS) {
      return ios;
    } else if (Platform.isMacOS) {
      return macos;
    } else if (Platform.isLinux) {
      return linux;
    } else if (Platform.isWindows) {
      return windows;
    } else {
      return web; // Default to web if platform is not recognized
    }
  }

  // Android Configuration
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'your-android-api-key',
    appId: 'your-android-app-id',
    messagingSenderId: 'your-android-messaging-sender-id',
    projectId: 'your-android-project-id',
    storageBucket: 'your-android-storage-bucket',
    databaseURL: 'your-android-database-url',
    iosClientId: 'your-android-ios-client-id',
    iosBundleId: 'your-android-ios-bundle-id',
  );

  // iOS Configuration
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'your-ios-api-key',
    appId: 'your-ios-app-id',
    messagingSenderId: 'your-ios-messaging-sender-id',
    projectId: 'your-ios-project-id',
    storageBucket: 'your-ios-storage-bucket',
    databaseURL: 'your-ios-database-url',
    iosClientId: 'your-ios-ios-client-id',
    iosBundleId: 'your-ios-ios-bundle-id',
  );

  // Web Configuration
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "AIzaSyCU5bnFETffjq3JfwdupsT0uXXCKjE0hqs",
    appId: "1:519164997072:web:50875c3770fec74331ddd5",
    messagingSenderId: "519164997072",
    projectId: "newcur-5e5d8",
    authDomain: "newcur-5e5d8.firebaseapp.com",
    storageBucket: "newcur-5e5d8.firebasestorage.app",
    measurementId: "G-CFMNDNYWDH",
    databaseURL: "https://currencydashboard-a280e-default-rtdb.firebaseio.com",
  );

  // macOS Configuration
  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'your-macos-api-key',
    appId: 'your-macos-app-id',
    messagingSenderId: 'your-macos-messaging-sender-id',
    projectId: 'your-macos-project-id',
    storageBucket: 'your-macos-storage-bucket',
    databaseURL: 'your-macos-database-url',
  );

  // Linux Configuration
  static const FirebaseOptions linux = FirebaseOptions(
    apiKey: 'your-linux-api-key',
    appId: 'your-linux-app-id',
    messagingSenderId: 'your-linux-messaging-sender-id',
    projectId: 'your-linux-project-id',
    storageBucket: 'your-linux-storage-bucket',
    databaseURL: 'your-linux-database-url',
  );

  // Windows Configuration
  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'your-windows-api-key',
    appId: 'your-windows-app-id',
    messagingSenderId: 'your-windows-messaging-sender-id',
    projectId: 'your-windows-project-id',
    storageBucket: 'your-windows-storage-bucket',
    databaseURL: 'your-windows-database-url',
  );
}
