import 'package:flutter/material.dart';

class RegionSpecificTaxScreen extends StatefulWidget {
  @override
  _RegionSpecificTaxScreenState createState() =>
      _RegionSpecificTaxScreenState();
}

class _RegionSpecificTaxScreenState extends State<RegionSpecificTaxScreen> {
  String? selectedCountry;
  String taxRate = '';
  TextEditingController _searchController = TextEditingController();
  late List<Map<String, String>> filteredCountries;

  final List<Map<String, String>> countriesTaxData = [
    {'country': 'Afghanistan', 'tax': '5%'},
    {'country': 'Algeria', 'tax': '10%'},
    {'country': 'Andorra', 'tax': '4.5%'},
    {'country': 'Angola', 'tax': '15%'},
    {'country': 'Antigua and Barbuda', 'tax': '10%'},
    {'country': 'Argentina', 'tax': '21%'},
    {'country': 'Armenia', 'tax': '20%'},
    {'country': 'Australia', 'tax': '15%'},
    {'country': 'Austria', 'tax': '20%'},
    {'country': 'Azerbaijan', 'tax': '18%'},
    {'country': 'Bahamas', 'tax': '7.5%'},
    {'country': 'Bahrain', 'tax': '5%'},
    {'country': 'Bangladesh', 'tax': '15%'},
    {'country': 'Barbados', 'tax': '17.5%'},
    {'country': 'Belarus', 'tax': '20%'},
    {'country': 'Belgium', 'tax': '21%'},
    {'country': 'Belize', 'tax': '12.5%'},
    {'country': 'Benin', 'tax': '18%'},
    {'country': 'Bhutan', 'tax': '5%'},
    {'country': 'Bolivia', 'tax': '13%'},
    {'country': 'Bosnia and Herzegovina', 'tax': '17%'},
    {'country': 'Botswana', 'tax': '12%'},
    {'country': 'Brazil', 'tax': '18%'},
    {'country': 'Brunei', 'tax': '0%'},
    {'country': 'Bulgaria', 'tax': '20%'},
    {'country': 'Burkina Faso', 'tax': '18%'},
    {'country': 'Burundi', 'tax': '18%'},
    {'country': 'Cambodia', 'tax': '10%'},
    {'country': 'Cameroon', 'tax': '19.25%'},
    {'country': 'Canada', 'tax': '12%'},
    {'country': 'Cape Verde', 'tax': '25%'},
    {'country': 'Central African Republic', 'tax': '19%'},
    {'country': 'Chad', 'tax': '18%'},
    {'country': 'Chile', 'tax': '19%'},
    {'country': 'China', 'tax': '13%'},
    {'country': 'Colombia', 'tax': '19%'},
    {'country': 'Comoros', 'tax': '10%'},
    {'country': 'Congo', 'tax': '18%'},
    {'country': 'Costa Rica', 'tax': '13%'},
    {'country': 'Croatia', 'tax': '25%'},
    {'country': 'Cuba', 'tax': '10%'},
    {'country': 'Cyprus', 'tax': '19%'},
    {'country': 'Czech Republic', 'tax': '21%'},
    {'country': 'Denmark', 'tax': '25%'},
    {'country': 'Djibouti', 'tax': '10%'},
    {'country': 'Dominica', 'tax': '15%'},
    {'country': 'Dominican Republic', 'tax': '18%'},
    {'country': 'Ecuador', 'tax': '12%'},
    {'country': 'Egypt', 'tax': '14%'},
    {'country': 'El Salvador', 'tax': '13%'},
    {'country': 'Equatorial Guinea', 'tax': '10%'},
    {'country': 'Eritrea', 'tax': '10%'},
    {'country': 'Estonia', 'tax': '20%'},
    {'country': 'Eswatini', 'tax': '14%'},
    {'country': 'Ethiopia', 'tax': '15%'},
    {'country': 'Fiji', 'tax': '9%'},
    {'country': 'Finland', 'tax': '24%'},
    {'country': 'France', 'tax': '20%'},
    {'country': 'Gabon', 'tax': '18%'},
    {'country': 'Gambia', 'tax': '15%'},
    {'country': 'Georgia', 'tax': '18%'},
    {'country': 'Germany', 'tax': '19%'},
    {'country': 'Ghana', 'tax': '15%'},
    {'country': 'Greece', 'tax': '24%'},
    {'country': 'Grenada', 'tax': '15%'},
    {'country': 'Guatemala', 'tax': '12%'},
    {'country': 'Guinea', 'tax': '18%'},
    {'country': 'Guinea-Bissau', 'tax': '12%'},
    {'country': 'Guyana', 'tax': '14%'},
    {'country': 'Haiti', 'tax': '10%'},
    {'country': 'Honduras', 'tax': '15%'},
    {'country': 'Hungary', 'tax': '27%'},
    {'country': 'Iceland', 'tax': '24%'},
    {'country': 'India', 'tax': '18%'},
    {'country': 'Indonesia', 'tax': '10%'},
    {'country': 'Iran', 'tax': '9%'},
    {'country': 'Iraq', 'tax': '15%'},
    {'country': 'Ireland', 'tax': '23%'},
    {'country': 'Israel', 'tax': '17%'},
    {'country': 'Italy', 'tax': '22%'},
    {'country': 'Jamaica', 'tax': '15%'},
    {'country': 'Japan', 'tax': '10%'},
    {'country': 'Jordan', 'tax': '16%'},
    {'country': 'Kazakhstan', 'tax': '12%'},
    {'country': 'Kenya', 'tax': '16%'},
    {'country': 'Kiribati', 'tax': '10%'},
    {'country': 'Korea, North', 'tax': '0%'},
    {'country': 'Korea, South', 'tax': '10%'},
    {'country': 'Kuwait', 'tax': '0%'},
    {'country': 'Kyrgyzstan', 'tax': '12%'},
    {'country': 'Laos', 'tax': '10%'},
    {'country': 'Latvia', 'tax': '21%'},
    {'country': 'Lebanon', 'tax': '11%'},
    {'country': 'Lesotho', 'tax': '14%'},
    {'country': 'Liberia', 'tax': '10%'},
    {'country': 'Libya', 'tax': '10%'},
    {'country': 'Liechtenstein', 'tax': '8%'},
    {'country': 'Lithuania', 'tax': '21%'},
    {'country': 'Luxembourg', 'tax': '17%'},
    {'country': 'Madagascar', 'tax': '10%'},
    {'country': 'Malawi', 'tax': '16%'},
    {'country': 'Malaysia', 'tax': '6%'},
    {'country': 'Maldives', 'tax': '6%'},
    {'country': 'Mali', 'tax': '18%'},
    {'country': 'Malta', 'tax': '18%'},
    {'country': 'Marshall Islands', 'tax': '0%'},
    {'country': 'Mauritania', 'tax': '14%'},
    {'country': 'Mauritius', 'tax': '15%'},
    {'country': 'Mexico', 'tax': '16%'},
    {'country': 'Micronesia', 'tax': '0%'},
    {'country': 'Moldova', 'tax': '20%'},
    {'country': 'Monaco', 'tax': '0%'},
    {'country': 'Mongolia', 'tax': '10%'},
    {'country': 'Montenegro', 'tax': '21%'},
    {'country': 'Morocco', 'tax': '20%'},
    {'country': 'Mozambique', 'tax': '17%'},
    {'country': 'Myanmar', 'tax': '10%'},
    {'country': 'Namibia', 'tax': '15%'},
    {'country': 'Nauru', 'tax': '10%'},
    {'country': 'Nepal', 'tax': '13%'},
    {'country': 'Netherlands', 'tax': '21%'},
    {'country': 'New Zealand', 'tax': '15%'},
    {'country': 'Nicaragua', 'tax': '15%'},
    {'country': 'Niger', 'tax': '18%'},
    {'country': 'Nigeria', 'tax': '7.5%'},
    {'country': 'North Macedonia', 'tax': '18%'},
    {'country': 'Norway', 'tax': '25%'},
    {'country': 'Oman', 'tax': '5%'},
    {'country': 'Pakistan', 'tax': '17%'},
    {'country': 'Palau', 'tax': '0%'},
    {'country': 'Panama', 'tax': '7%'},
    {'country': 'Papua New Guinea', 'tax': '10%'},
    {'country': 'Paraguay', 'tax': '10%'},
    {'country': 'Peru', 'tax': '18%'},
    {'country': 'Philippines', 'tax': '12%'},
    {'country': 'Poland', 'tax': '23%'},
    {'country': 'Portugal', 'tax': '23%'},
    {'country': 'Qatar', 'tax': '0%'},
    {'country': 'Romania', 'tax': '19%'},
    {'country': 'Russia', 'tax': '20%'},
    {'country': 'Rwanda', 'tax': '18%'},
    {'country': 'Saint Kitts and Nevis', 'tax': '0%'},
    {'country': 'Saint Lucia', 'tax': '15%'},
    {'country': 'Saint Vincent and the Grenadines', 'tax': '16%'},
    {'country': 'Samoa', 'tax': '15%'},
    {'country': 'San Marino', 'tax': '17%'},
    {'country': 'Sao Tome and Principe', 'tax': '15%'},
    {'country': 'Saudi Arabia', 'tax': '15%'},
    {'country': 'Senegal', 'tax': '18%'},
    {'country': 'Serbia', 'tax': '20%'},
    {'country': 'Seychelles', 'tax': '15%'},
    {'country': 'Sierra Leone', 'tax': '15%'},
    {'country': 'Singapore', 'tax': '7%'},
    {'country': 'Slovakia', 'tax': '20%'},
    {'country': 'Slovenia', 'tax': '22%'},
    {'country': 'Solomon Islands', 'tax': '10%'},
    {'country': 'Somalia', 'tax': '15%'},
    {'country': 'South Africa', 'tax': '15%'},
    {'country': 'South Sudan', 'tax': '10%'},
    {'country': 'Spain', 'tax': '21%'},
    {'country': 'Sri Lanka', 'tax': '8%'},
    {'country': 'Sudan', 'tax': '17%'},
    {'country': 'Suriname', 'tax': '10%'},
    {'country': 'Sweden', 'tax': '25%'},
    {'country': 'Switzerland', 'tax': '7.7%'},
    {'country': 'Syria', 'tax': '10%'},
    {'country': 'Taiwan', 'tax': '5%'},
    {'country': 'Tajikistan', 'tax': '18%'},
    {'country': 'Tanzania', 'tax': '18%'},
    {'country': 'Thailand', 'tax': '7%'},
    {'country': 'Timor-Leste', 'tax': '10%'},
    {'country': 'Togo', 'tax': '18%'},
    {'country': 'Tonga', 'tax': '15%'},
    {'country': 'Trinidad and Tobago', 'tax': '15%'},
    {'country': 'Tunisia', 'tax': '19%'},
    {'country': 'Turkey', 'tax': '18%'},
    {'country': 'Turkmenistan', 'tax': '15%'},
    {'country': 'Tuvalu', 'tax': '8%'},
    {'country': 'Uganda', 'tax': '18%'},
    {'country': 'Ukraine', 'tax': '20%'},
    {'country': 'United Arab Emirates', 'tax': '5%'},
    {'country': 'United Kingdom', 'tax': '20%'},
    {'country': 'United States', 'tax': '5%'},
    {'country': 'Uruguay', 'tax': '22%'},
    {'country': 'Uzbekistan', 'tax': '15%'},
    {'country': 'Vanuatu', 'tax': '0%'},
    {'country': 'Vatican City', 'tax': '0%'},
    {'country': 'Venezuela', 'tax': '16%'},
    {'country': 'Vietnam', 'tax': '10%'},
    {'country': 'Yemen', 'tax': '5%'},
    {'country': 'Zambia', 'tax': '16%'},
    {'country': 'Zimbabwe', 'tax': '15%'},
  ];

  @override
  void initState() {
    super.initState();
    filteredCountries = countriesTaxData;
  }

  void filterCountries(String query) {
    setState(() {
      filteredCountries = countriesTaxData
          .where((country) =>
          country['country']!.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  // void onCountrySelected(String? newValue) {
  //   setState(() {
  //     selectedCountry = newValue;
  //     if (selectedCountry != null) {
  //       taxRate = countriesTaxData
  //           .firstWhere((item) => item['country'] == selectedCountry)['tax']!;
  //     }
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Region-Specific Tax Information'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SearchField(
              controller: _searchController,
              onChanged: filterCountries,
            ),
            SizedBox(height: 16),
            // CountryDropdown(
            //   selectedCountry: selectedCountry,
            //   filteredCountries: filteredCountries,
            //   // onCountrySelected: onCountrySelected,
            // ),
            SizedBox(height: 16),
            Expanded(
              child: filteredCountries.isEmpty
                  ? Center(child: Text('No countries match your search.'))
                  : ListView.builder(
                itemCount: filteredCountries.length,
                itemBuilder: (context, index) {
                  final country = filteredCountries[index];
                  return CountryCard(
                    countryName: country['country']!,
                    taxRate: country['tax']!,
                  );
                },
              ),
            ),
            SizedBox(height: 16),
            if (selectedCountry != null)
              TaxRateDisplay(taxRate: taxRate),
          ],
        ),
      ),
    );
  }
}

class SearchField extends StatefulWidget {
  final TextEditingController controller;
  final Function(String) onChanged;

  const SearchField({
    required this.controller,
    required this.onChanged,
  });

  @override
  _SearchFieldState createState() => _SearchFieldState();
}

class _SearchFieldState extends State<SearchField> {
  late String query;
  late TextEditingController controller;
  late FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    controller = widget.controller;
    _focusNode = FocusNode();
    query = '';
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  void _clearSearch() {
    controller.clear();
    widget.onChanged('');
    FocusScope.of(context).unfocus();
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      focusNode: _focusNode,
      onChanged: (value) {
        setState(() {
          query = value;
        });
        widget.onChanged(value);
      },
      decoration: InputDecoration(
        labelText: 'Search Country',
        hintText: 'Search by country name',
        prefixIcon: Icon(Icons.search),
        suffixIcon: query.isNotEmpty
            ? IconButton(
          icon: Icon(Icons.clear),
          onPressed: _clearSearch,
        )
            : null,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
        filled: true,
        fillColor: Colors.grey[200],
      ),
    );
  }
}

class CountryDropdown extends StatelessWidget {
  final String? selectedCountry;
  final List<Map<String, String>> filteredCountries;
  final Function(String?) onCountrySelected;

  const CountryDropdown({
    required this.selectedCountry,
    required this.filteredCountries,
    required this.onCountrySelected,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: selectedCountry,
      hint: Text("Select Country"),
      decoration: InputDecoration(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
        filled: true,
      ),
      onChanged: onCountrySelected,
      items: filteredCountries
          .map<DropdownMenuItem<String>>((Map<String, String> country) {
        return DropdownMenuItem<String>(
          value: country['country'],
          child: Text(country['country']!),
        );
      }).toList(),
    );
  }
}

class TaxRateDisplay extends StatelessWidget {
  final String taxRate;

  const TaxRateDisplay({required this.taxRate});

  @override
  Widget build(BuildContext context) {
    return Text(
      'Tax Rate: $taxRate',
      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
    );
  }
}

class CountryCard extends StatelessWidget {
  final String countryName;
  final String taxRate;

  const CountryCard({
    required this.countryName,
    required this.taxRate,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      margin: EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Text(countryName, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('Tax Rate: $taxRate'),
      ),
    );
  }
}