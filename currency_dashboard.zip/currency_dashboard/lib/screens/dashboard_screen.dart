import 'package:flutter/material.dart';
import '../widgets/drawer_widget.dart'; // Import your custom drawer widget
import 'currency_conversion_screen.dart';
import 'wallet_screen.dart';
import 'receipt_screen.dart';
import 'settings_screen.dart';
import 'region_tax_screen.dart';  // Import RegionSpecificTaxScreen
import 'country_currency_screen.dart';  // Import CountryCurrencyScreen

class DashboardScreen extends StatelessWidget {
  // Reusable button widget
  Widget _buildButton(String text, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      child: Text(text),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Dashboard")),
      drawer: DrawerWidget(),  // Your custom Drawer widget
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(  // Center everything inside the body
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "Welcome to the Currency convert Dashboard!",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center, // Center the text
              ),
              SizedBox(height: 40),

              // Currency Conversion Button
              _buildButton(
                'Currency Conversion',
                    () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => CurrencyConversionScreen()),
                  );
                },
              ),
              SizedBox(height: 20),

              // Wallet Button
              // _buildButton(
              //   'Wallet',
              //       () {
              //     Navigator.push(
              //       context,
              //       MaterialPageRoute(builder: (context) => WalletScreen()),
              //     );
              //   },
              // ),
              // SizedBox(height: 20),
              //
              // // Receipts Button
              // _buildButton(
              //   'Receipts',
              //       () {
              //     Navigator.push(
              //       context,
              //       MaterialPageRoute(builder: (context) => ReceiptScreen()),
              //     );
              //   },
              // ),
              // SizedBox(height: 20),
              //
              // // Settings Button
              // _buildButton(
              //   'Settings',
              //       () {
              //     Navigator.push(
              //       context,
              //       MaterialPageRoute(builder: (context) => SettingsScreen()),
              //     );
              //   },
              // ),
              // SizedBox(height: 20),
              //
              // // Region-Specific Tax Button
              // _buildButton(
              //   'Region-Specific Tax',
              //       () {
              //     Navigator.push(
              //       context,
              //       MaterialPageRoute(builder: (context) => RegionSpecificTaxScreen()),
              //     );
              //   },
              // ),
              // SizedBox(height: 20),

              // Country with Currency Button
              // _buildButton(
              //   'Country with Currency',
              //       () {
              //     Navigator.push(
              //       context,
              //       MaterialPageRoute(builder: (context) => CountryCurrencyScreen()),
              //     );
              //   },
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
