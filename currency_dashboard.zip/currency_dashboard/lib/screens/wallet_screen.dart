import 'package:flutter/material.dart';

class WalletScreen extends StatefulWidget {
  @override
  _WalletScreenState createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  double _balance = 0.0;
  List<String> _transactionHistory = [];

  void _topUp() {
    setState(() {
      _balance += 100.0;  // Example top-up amount
      _transactionHistory.add('Top-up: \$100.00');
    });
  }

  void _withdraw() {
    setState(() {
      if (_balance >= 50.0) {
        _balance -= 50.0;  // Example withdrawal amount
        _transactionHistory.add('Withdrawal: \$50.00');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Insufficient balance')),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Wallet")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              "Balance: \$${_balance.toStringAsFixed(2)}",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _topUp,
              child: Text("Top-Up \$100"),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _withdraw,
              child: Text("Withdraw \$50"),
            ),
            SizedBox(height: 20),
            Text(
              "Transaction History:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _transactionHistory.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(_transactionHistory[index]),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
