import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Settings"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _buildNotificationSetting(context), // Pass context here
            SizedBox(height: 20),
            _buildFeedbackSetting(context), // Pass context here
            SizedBox(height: 20),
            _buildSupportSetting(context), // Pass context here
            SizedBox(height: 20),
            _buildPrivacyPolicySetting(context), // Pass context here
          ],
        ),
      ),
    );
  }

  // Notifications Setting
  Widget _buildNotificationSetting(BuildContext context) {
    return Card(
      elevation: 5,
      child: ListTile(
        title: Text("Notifications"),
        trailing: Switch(
          value: true, // You can manage this state for notifications
          onChanged: (bool value) {
            // Handle the switch toggle here
          },
        ),
      ),
    );
  }

  // User Feedback Setting
  Widget _buildFeedbackSetting(BuildContext context) {
    return Card(
      elevation: 5,
      child: ListTile(
        title: Text("Feedback"),
        trailing: Icon(Icons.arrow_forward_ios),
        onTap: () {
          // Navigate to feedback screen
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => FeedbackScreen()),
          );
        },
      ),
    );
  }

  // Support Setting
  Widget _buildSupportSetting(BuildContext context) {
    return Card(
      elevation: 5,
      child: ListTile(
        title: Text("Support"),
        trailing: Icon(Icons.arrow_forward_ios),
        onTap: () {
          // Navigate to support screen
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => SupportScreen()),
          );
        },
      ),
    );
  }

  // Privacy Policy Setting
  Widget _buildPrivacyPolicySetting(BuildContext context) {
    return Card(
      elevation: 5,
      child: ListTile(
        title: Text("Privacy Policy"),
        trailing: Icon(Icons.arrow_forward_ios),
        onTap: () {
          // Navigate to privacy policy screen
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PrivacyPolicyScreen()),
          );
        },
      ),
    );
  }
}

// Feedback Screen
class FeedbackScreen extends StatefulWidget {
  @override
  _FeedbackScreenState createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  final _feedbackController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  // Submit feedback
  void _submitFeedback() {
    if (_formKey.currentState?.validate() ?? false) {
      String feedback = _feedbackController.text;
      // Here, you can save or process the feedback

      // Show confirmation
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Feedback submitted successfully!")),
      );

      _feedbackController.clear(); // Clear the field
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Feedback")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("We value your feedback. Please let us know your thoughts:",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 20),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _feedbackController,
                    decoration: InputDecoration(
                      labelText: "Enter your feedback",
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 5,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your feedback';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _submitFeedback,
                    child: Text("Submit Feedback"),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Support Screen
class SupportScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Support")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("For support, please contact us at:", style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text("Talha@gmail.com", style: TextStyle(fontSize: 16, color: Colors.blue)),
            SizedBox(height: 20),
            Text("Or check out our FAQ below:", style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text("Q1: How can I reset my password?", style: TextStyle(fontSize: 16)),
            Text("A1: You can reset your password by clicking the 'Forgot Password' link on the login screen.", style: TextStyle(fontSize: 16)),
            // Add more FAQs here
          ],
        ),
      ),
    );
  }
}

// Privacy Policy Screen
class PrivacyPolicyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Privacy Policy")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Privacy Policy", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text(
              "Your privacy is important to us. This privacy policy explains how we collect, use, store, and protect your personal data. By using our app, you consent to the practices outlined in this policy.\n\n"
                  "1. **Information We Collect**: We may collect personal information such as your name, email address, phone number, and other details when you use our app. We may also collect non-personal information like device type, usage data, and IP address to improve your experience.\n\n"
                  "2. **How We Use Your Information**: The information we collect is used to provide, personalize, and improve our services. We may also use your data for customer support, marketing communications, and notifications about new features or updates.\n\n"
                  "3. **Data Security**: We take reasonable measures to protect your data from unauthorized access, alteration, disclosure, or destruction. However, please be aware that no method of electronic transmission or storage is 100% secure.\n\n"
                  "4. **Third-Party Services**: We may use third-party services that collect, store, and analyze your data. These third-party providers are obligated to comply with applicable data protection laws and safeguard your personal information.\n\n"
                  "5. **Your Rights**: You have the right to access, update, or delete your personal information. You can also withdraw your consent to data processing at any time by contacting us.\n\n"
                  "6. **Changes to This Privacy Policy**: We reserve the right to update this privacy policy at any time. We will notify you of any changes by posting the updated policy on this page.\n\n"
                  "If you have any questions or concerns about our privacy practices, please contact us at Talha@gmail.com.",
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            Text("For more information, please contact us at Jatt@gmail.com", style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

// Notification Settings Screen
class NotificationSettingsScreen extends StatefulWidget {
  @override
  _NotificationSettingsScreenState createState() =>
      _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  bool _notificationsEnabled = true;

  // Toggle notifications setting
  void _toggleNotifications(bool value) {
    setState(() {
      _notificationsEnabled = value;
    });
    // You can also save the state here, or update the backend if needed
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Notification Settings")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text("Enable or disable notifications.", style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            SwitchListTile(
              title: Text("Notifications"),
              value: _notificationsEnabled,
              onChanged: _toggleNotifications,
            ),
          ],
        ),
      ),
    );
  }
}
