import 'package:flutter/material.dart';
import 'dart:convert'; // For json.decode
import 'package:http/http.dart' as http; // For network requests
class CurrencyConversionScreen extends StatefulWidget {
  @override
  _CurrencyConversionScreenState createState() =>
      _CurrencyConversionScreenState();
}

class _CurrencyConversionScreenState extends State<CurrencyConversionScreen> {
  final List<String> currencyCodes = [
    'AED', 'AFN', 'ALL', 'AMD', 'ANG', 'AOA', 'ARS', 'AUD', 'AWG', 'AZN',
    'BAM', 'BBD', 'BDT', 'BGN', 'BHD', 'BIF', 'BMD', 'BND', 'BOB', 'BRL',
    'BSD', 'BTN', 'BWP', 'BYN', 'BZD', 'CAD', 'CDF', 'CHF', 'CLP', 'CNY',
    'COP', 'CRC', 'CUP', 'CVE', 'CZK', 'DJF', 'DKK', 'DOP', 'DZD', 'EGP',
    'ERN', 'ETB', 'EUR', 'FJD', 'FKP', 'FOK', 'GBP', 'GEL', 'GGP', 'GHS',
    'GIP', 'GMD', 'GNF', 'GTQ', 'GYD', 'HKD', 'HNL', 'HRK', 'HTG', 'HUF',
    'IDR', 'ILS', 'IMP', 'INR', 'IQD', 'IRR', 'ISK', 'JEP', 'JMD', 'JOD',
    'JPY', 'KES', 'KGS', 'KHR', 'KID', 'KMF', 'KRW', 'KWD', 'KYD', 'KZT',
    'LAK', 'LBP', 'LKR', 'LRD', 'LSL', 'LYD', 'MAD', 'MDL', 'MGA', 'MKD',
    'MMK', 'MNT', 'MOP', 'MRU', 'MUR', 'MVR', 'MWK', 'MXN', 'MYR', 'MZN',
    'NAD', 'NGN', 'NIO', 'NOK', 'NPR', 'NZD', 'OMR', 'PAB', 'PEN', 'PGK',
    'PHP', 'PKR', 'PLN', 'PYG', 'QAR', 'RON', 'RSD', 'RUB', 'RWF', 'SAR',
    'SBD', 'SCR', 'SDG', 'SEK', 'SGD', 'SHP', 'SLE', 'SLL', 'SOS', 'SRD',
    'SSP', 'STN', 'SYP', 'SZL', 'THB', 'TJS', 'TMT', 'TND', 'TOP', 'TRY',
    'TTD', 'TVD', 'TWD', 'TZS', 'UAH', 'UGX', 'USD', 'UYU', 'UZS', 'VES',
    'VND', 'VUV', 'WST', 'XAF', 'XCD', 'XOF', 'XPF', 'YER', 'ZAR', 'ZMW', 'ZWL'
    // Add your list of currency codes here
  ];

  final List<Map<String, String>> countriesTaxData = [
    {'country': 'Afghanistan', 'tax': '5%'},
    {'country': 'Algeria', 'tax': '10%'},
    {'country': 'Andorra', 'tax': '4.5%'},
    {'country': 'Angola', 'tax': '15%'},
    {'country': 'Antigua and Barbuda', 'tax': '10%'},
    {'country': 'Argentina', 'tax': '21%'},
    {'country': 'Armenia', 'tax': '20%'},
    {'country': 'Australia', 'tax': '15%'},
    {'country': 'Austria', 'tax': '20%'},
    {'country': 'Azerbaijan', 'tax': '18%'},
    {'country': 'Bahamas', 'tax': '7.5%'},
    {'country': 'Bahrain', 'tax': '5%'},
    {'country': 'Bangladesh', 'tax': '15%'},
    {'country': 'Barbados', 'tax': '17.5%'},
    {'country': 'Belarus', 'tax': '20%'},
    {'country': 'Belgium', 'tax': '21%'},
    {'country': 'Belize', 'tax': '12.5%'},
    {'country': 'Benin', 'tax': '18%'},
    {'country': 'Bhutan', 'tax': '5%'},
    {'country': 'Bolivia', 'tax': '13%'},
    {'country': 'Bosnia and Herzegovina', 'tax': '17%'},
    {'country': 'Botswana', 'tax': '12%'},
    {'country': 'Brazil', 'tax': '18%'},
    {'country': 'Brunei', 'tax': '0%'},
    {'country': 'Bulgaria', 'tax': '20%'},
    {'country': 'Burkina Faso', 'tax': '18%'},
    {'country': 'Burundi', 'tax': '18%'},
    {'country': 'Cambodia', 'tax': '10%'},
    {'country': 'Cameroon', 'tax': '19.25%'},
    {'country': 'Canada', 'tax': '12%'},
    {'country': 'Cape Verde', 'tax': '25%'},
    {'country': 'Central African Republic', 'tax': '19%'},
    {'country': 'Chad', 'tax': '18%'},
    {'country': 'Chile', 'tax': '19%'},
    {'country': 'China', 'tax': '13%'},
    {'country': 'Colombia', 'tax': '19%'},
    {'country': 'Comoros', 'tax': '10%'},
    {'country': 'Congo', 'tax': '18%'},
    {'country': 'Costa Rica', 'tax': '13%'},
    {'country': 'Croatia', 'tax': '25%'},
    {'country': 'Cuba', 'tax': '10%'},
    {'country': 'Cyprus', 'tax': '19%'},
    {'country': 'Czech Republic', 'tax': '21%'},
    {'country': 'Denmark', 'tax': '25%'},
    {'country': 'Djibouti', 'tax': '10%'},
    {'country': 'Dominica', 'tax': '15%'},
    {'country': 'Dominican Republic', 'tax': '18%'},
    {'country': 'Ecuador', 'tax': '12%'},
    {'country': 'Egypt', 'tax': '14%'},
    {'country': 'El Salvador', 'tax': '13%'},
    {'country': 'Equatorial Guinea', 'tax': '10%'},
    {'country': 'Eritrea', 'tax': '10%'},
    {'country': 'Estonia', 'tax': '20%'},
    {'country': 'Eswatini', 'tax': '14%'},
    {'country': 'Ethiopia', 'tax': '15%'},
    {'country': 'Fiji', 'tax': '9%'},
    {'country': 'Finland', 'tax': '24%'},
    {'country': 'France', 'tax': '20%'},
    {'country': 'Gabon', 'tax': '18%'},
    {'country': 'Gambia', 'tax': '15%'},
    {'country': 'Georgia', 'tax': '18%'},
    {'country': 'Germany', 'tax': '19%'},
    {'country': 'Ghana', 'tax': '15%'},
    {'country': 'Greece', 'tax': '24%'},
    {'country': 'Grenada', 'tax': '15%'},
    {'country': 'Guatemala', 'tax': '12%'},
    {'country': 'Guinea', 'tax': '18%'},
    {'country': 'Guinea-Bissau', 'tax': '12%'},
    {'country': 'Guyana', 'tax': '14%'},
    {'country': 'Haiti', 'tax': '10%'},
    {'country': 'Honduras', 'tax': '15%'},
    {'country': 'Hungary', 'tax': '27%'},
    {'country': 'Iceland', 'tax': '24%'},
    {'country': 'India', 'tax': '18%'},
    {'country': 'Indonesia', 'tax': '10%'},
    {'country': 'Iran', 'tax': '9%'},
    {'country': 'Iraq', 'tax': '15%'},
    {'country': 'Ireland', 'tax': '23%'},
    {'country': 'Israel', 'tax': '17%'},
    {'country': 'Italy', 'tax': '22%'},
    {'country': 'Jamaica', 'tax': '15%'},
    {'country': 'Japan', 'tax': '10%'},
    {'country': 'Jordan', 'tax': '16%'},
    {'country': 'Kazakhstan', 'tax': '12%'},
    {'country': 'Kenya', 'tax': '16%'},
    {'country': 'Kiribati', 'tax': '10%'},
    {'country': 'Korea, North', 'tax': '0%'},
    {'country': 'Korea, South', 'tax': '10%'},
    {'country': 'Kuwait', 'tax': '0%'},
    {'country': 'Kyrgyzstan', 'tax': '12%'},
    {'country': 'Laos', 'tax': '10%'},
    {'country': 'Latvia', 'tax': '21%'},
    {'country': 'Lebanon', 'tax': '11%'},
    {'country': 'Lesotho', 'tax': '14%'},
    {'country': 'Liberia', 'tax': '10%'},
    {'country': 'Libya', 'tax': '10%'},
    {'country': 'Liechtenstein', 'tax': '8%'},
    {'country': 'Lithuania', 'tax': '21%'},
    {'country': 'Luxembourg', 'tax': '17%'},
    {'country': 'Madagascar', 'tax': '10%'},
    {'country': 'Malawi', 'tax': '16%'},
    {'country': 'Malaysia', 'tax': '6%'},
    {'country': 'Maldives', 'tax': '6%'},
    {'country': 'Mali', 'tax': '18%'},
    {'country': 'Malta', 'tax': '18%'},
    {'country': 'Marshall Islands', 'tax': '0%'},
    {'country': 'Mauritania', 'tax': '14%'},
    {'country': 'Mauritius', 'tax': '15%'},
    {'country': 'Mexico', 'tax': '16%'},
    {'country': 'Micronesia', 'tax': '0%'},
    {'country': 'Moldova', 'tax': '20%'},
    {'country': 'Monaco', 'tax': '0%'},
    {'country': 'Mongolia', 'tax': '10%'},
    {'country': 'Montenegro', 'tax': '21%'},
    {'country': 'Morocco', 'tax': '20%'},
    {'country': 'Mozambique', 'tax': '17%'},
    {'country': 'Myanmar', 'tax': '10%'},
    {'country': 'Namibia', 'tax': '15%'},
    {'country': 'Nauru', 'tax': '10%'},
    {'country': 'Nepal', 'tax': '13%'},
    {'country': 'Netherlands', 'tax': '21%'},
    {'country': 'New Zealand', 'tax': '15%'},
    {'country': 'Nicaragua', 'tax': '15%'},
    {'country': 'Niger', 'tax': '18%'},
    {'country': 'Nigeria', 'tax': '7.5%'},
    {'country': 'North Macedonia', 'tax': '18%'},
    {'country': 'Norway', 'tax': '25%'},
    {'country': 'Oman', 'tax': '5%'},
    {'country': 'Pakistan', 'tax': '17%'},
    {'country': 'Palau', 'tax': '0%'},
    {'country': 'Panama', 'tax': '7%'},
    {'country': 'Papua New Guinea', 'tax': '10%'},
    {'country': 'Paraguay', 'tax': '10%'},
    {'country': 'Peru', 'tax': '18%'},
    {'country': 'Philippines', 'tax': '12%'},
    {'country': 'Poland', 'tax': '23%'},
    {'country': 'Portugal', 'tax': '23%'},
    {'country': 'Qatar', 'tax': '0%'},
    {'country': 'Romania', 'tax': '19%'},
    {'country': 'Russia', 'tax': '20%'},
    {'country': 'Rwanda', 'tax': '18%'},
    {'country': 'Saint Kitts and Nevis', 'tax': '0%'},
    {'country': 'Saint Lucia', 'tax': '15%'},
    {'country': 'Saint Vincent and the Grenadines', 'tax': '16%'},
    {'country': 'Samoa', 'tax': '15%'},
    {'country': 'San Marino', 'tax': '17%'},
    {'country': 'Sao Tome and Principe', 'tax': '15%'},
    {'country': 'Saudi Arabia', 'tax': '15%'},
    {'country': 'Senegal', 'tax': '18%'},
    {'country': 'Serbia', 'tax': '20%'},
    {'country': 'Seychelles', 'tax': '15%'},
    {'country': 'Sierra Leone', 'tax': '15%'},
    {'country': 'Singapore', 'tax': '7%'},
    {'country': 'Slovakia', 'tax': '20%'},
    {'country': 'Slovenia', 'tax': '22%'},
    {'country': 'Solomon Islands', 'tax': '10%'},
    {'country': 'Somalia', 'tax': '15%'},
    {'country': 'South Africa', 'tax': '15%'},
    {'country': 'South Korea', 'tax': '10%'},
    {'country': 'South Sudan', 'tax': '12%'},
    {'country': 'Spain', 'tax': '21%'},
    {'country': 'Sri Lanka', 'tax': '8%'},
    {'country': 'Sudan', 'tax': '17%'},
    {'country': 'Suriname', 'tax': '10%'},
    {'country': 'Sweden', 'tax': '25%'},
    {'country': 'Switzerland', 'tax': '7.7%'},
    {'country': 'Syria', 'tax': '20%'},
    {'country': 'Taiwan', 'tax': '5%'},
    {'country': 'Tajikistan', 'tax': '18%'},
    {'country': 'Tanzania', 'tax': '18%'},
    {'country': 'Thailand', 'tax': '7%'},
    {'country': 'Timor-Leste', 'tax': '10%'},
    {'country': 'Togo', 'tax': '18%'},
    {'country': 'Tonga', 'tax': '15%'},
    {'country': 'Trinidad and Tobago', 'tax': '12.5%'},
    {'country': 'Tunisia', 'tax': '19%'},
    {'country': 'Turkey', 'tax': '18%'},
    {'country': 'Turkmenistan', 'tax': '15%'},
    {'country': 'Tuvalu', 'tax': '10%'},
    {'country': 'Uganda', 'tax': '18%'},
    {'country': 'Ukraine', 'tax': '20%'},
    {'country': 'United Arab Emirates', 'tax': '5%'},
    {'country': 'United Kingdom', 'tax': '20%'},
    {'country': 'United States', 'tax': '8%'},
    {'country': 'Uruguay', 'tax': '22%'},
    {'country': 'Uzbekistan', 'tax': '20%'},
    {'country': 'Vanuatu', 'tax': '12%'},
    {'country': 'Vatican City', 'tax': '0%'},
    {'country': 'Venezuela', 'tax': '16%'},
    {'country': 'Vietnam', 'tax': '10%'},
    {'country': 'Yemen', 'tax': '5%'},
    {'country': 'Zambia', 'tax': '16%'},
    {'country': 'Zimbabwe', 'tax': '15%'},
  ];
  String fromCurrency = 'USD';
  String toCurrency = 'PKR';
  double exchangeRate = 1.0;
  double taxRate = 0.0;
  final TextEditingController amountController = TextEditingController();
  String result = '';
  double finalAmountAfterTax = 0.0;

  Future<void> fetchExchangeRate() async {
    try {
      final response = await http.get(Uri.parse(
          'https://api.exchangerate-api.com/v4/latest/$fromCurrency'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          exchangeRate = data['rates'][toCurrency] ?? 1.0;
        });
      } else {
        throw Exception('Failed to fetch exchange rates');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error fetching exchange rate: $e')),
      );
    }
  }




  void updateTaxRate(String country) {
    final countryData = countriesTaxData.firstWhere(
          (data) => data['country'] == country,
      orElse: () => {'tax': '0%'}, // Default tax if not found
    );
    setState(() {
      taxRate = double.tryParse(countryData['tax']?.replaceAll('%', '') ?? '0') ?? 0.0;
    });
  }

  @override
  void initState() {
    super.initState();
    fetchExchangeRate(); // Initial fetch
    updateTaxRate('Afghanistan'); // Default country tax rate
  }

  void convertCurrency() {
    if (amountController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter an amount')),
      );
      return;
    }
    double amount = double.tryParse(amountController.text) ?? 0.0;
    double convertedAmount = amount * exchangeRate;

    // Apply tax after conversion
    double taxAmount = convertedAmount * (taxRate / 100);
    finalAmountAfterTax = convertedAmount - taxAmount;

    setState(() {
      result =
      '$amount $fromCurrency = ${convertedAmount.toStringAsFixed(2)} $toCurrency';
    });

    // Display payment after tax
    if (finalAmountAfterTax > 0.0) {
      setState(() {
        result += '\nPayment after tax: ${finalAmountAfterTax.toStringAsFixed(2)} $toCurrency';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Currency Converter'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            DropdownButton<String>(
              value: fromCurrency,
              onChanged: (newValue) {
                setState(() {
                  fromCurrency = newValue!;
                });
                fetchExchangeRate(); // Fetch the new exchange rate
              },
              items: currencyCodes
                  .map((currency) => DropdownMenuItem<String>(
                value: currency,
                child: Text(currency),
              ))
                  .toList(),
            ),
            SizedBox(height: 16),
            DropdownButton<String>(
              value: toCurrency,
              onChanged: (newValue) {
                setState(() {
                  toCurrency = newValue!;
                });
                fetchExchangeRate(); // Fetch the new exchange rate
              },
              items: currencyCodes
                  .map((currency) => DropdownMenuItem<String>(
                value: currency,
                child: Text(currency),
              ))
                  .toList(),
            ),
            SizedBox(height: 16),
            TextField(
              controller: amountController,
              decoration: InputDecoration(labelText: 'Enter Amount'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: convertCurrency,
              child: Text('Convert'),
            ),
            SizedBox(height: 16),
            Text(
              result,
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }

}