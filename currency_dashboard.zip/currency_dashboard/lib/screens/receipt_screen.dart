import 'package:flutter/material.dart';
import 'dart:math'; // For generating random receipt numbers

class ReceiptScreen extends StatefulWidget {
  @override
  _ReceiptScreenState createState() => _ReceiptScreenState();
}

class _ReceiptScreenState extends State<ReceiptScreen> {
  // List to store the currency conversion history
  List<CurrencyConversion> transactions = [];

  // Function to simulate a currency conversion with dynamic receipt numbers
  void saveConversion(String details) {
    final random = Random();
    String receiptNumber = 'REC${random.nextInt(10000).toString().padLeft(4, '0')}';

    setState(() {
      transactions.add(CurrencyConversion(
        receiptNumber: receiptNumber,
        conversionDetails: details,
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Receipts'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Transaction Receipts',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            // ListView to display previous transactions
            Expanded(
              child: ListView.builder(
                itemCount: transactions.length,
                itemBuilder: (context, index) {
                  final transaction = transactions[index];
                  return Card(
                    child: ListTile(
                      title: Text('Receipt #${transaction.receiptNumber}'),
                      subtitle: Text(transaction.conversionDetails),
                      trailing: Icon(Icons.arrow_forward),
                      onTap: () {
                        // Navigate to a detailed view of the receipt if required
                      },
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 20),
            // Button to simulate a currency conversion and save it
            ElevatedButton(
              onPressed: () {
                // Simulating a currency conversion. Replace with actual logic.
                saveConversion(
                  'USD to EUR conversion: 100 USD = 90 EUR',
                );
              },
              child: Text('Simulate Currency Conversion'),
            ),
          ],
        ),
      ),
    );
  }
}

class CurrencyConversion {
  final String receiptNumber;
  final String conversionDetails;

  CurrencyConversion({required this.receiptNumber, required this.conversionDetails});
}
