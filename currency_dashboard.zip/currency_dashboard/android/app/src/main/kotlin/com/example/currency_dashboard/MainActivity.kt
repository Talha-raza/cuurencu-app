package com.example.currency_dashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
